<?php
$admin_user = "admin";
$admin_pass = "Sup3rS3cr3t";
?>
