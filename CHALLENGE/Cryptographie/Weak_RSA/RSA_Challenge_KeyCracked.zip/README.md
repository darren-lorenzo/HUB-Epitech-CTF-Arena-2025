# 🔐 Challenge RSA - Key Cracked

Une entreprise a tenté d'implémenter RSA, mais elle a choisi une clé très faible.
Peux-tu retrouver le message original à partir des informations contenues dans `output.txt` ?
Bonne chance !
