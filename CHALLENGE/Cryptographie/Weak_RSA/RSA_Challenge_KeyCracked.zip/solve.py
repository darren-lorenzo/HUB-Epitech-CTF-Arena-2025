from Crypto.Util.number import long_to_bytes, inverse
import sympy

n = 90763
e = 17
c = 79050

factors = list(sympy.factorint(n).keys())
p, q = factors[0], factors[1]
phi = (p - 1) * (q - 1)
d = inverse(e, phi)
m = pow(c, d, n)
print(long_to_bytes(m))
